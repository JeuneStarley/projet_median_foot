<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accueil</title>
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" src="script.js"></script>
</head>
<body >

    <nav>
        
        <div class="navima">
            <a href="#"> <img src ="image/info.png" ></a>    
        </div>
       
        <ul>
            <li><a href="index.php">Accueil</a></li>
            <li><a href="tirage.php">Groupes</a></li>
            <li><a href="#">Match</a></li>
            <li><a href="#">Classement</a></li>
        </ul>
        <div class="navimaj">
            <a href="#"> <img src ="image/face.png" ></a>
            <a href="#"><img src ="image/insta.png"></a>
            <a href="#"><img src ="image/twet.png"></a>     
        </div>
        <div class="rechech">
           
            <input style="" type="shearch" placeholder="recherche" >
            <img src ="image/rech.png" >
        </div>
    </nav>
    
   

    
    <table >
        <thead>
            <caption>
                <h2>LES CHAPEAUX</h2>
            </caption>
        <tr><th>Chapeau 1 </th><th>Chapeau 2</th><th>Chapeau 3</th><th>Chapeau 4</th></tr>
    </thead>
  
        <tr >
      
            <td>   Bresil <img class="imj" src ="image/bresil.png" ></td>
            <td><img class="imj" src ="image/france.png" >France</td>
            <td><img class="imj" src ="image/espagne.png" >Espagne</td>
            <td><img class="imj" src ="image/portugale.png" >Portugal</td>
        </tr>
    
        <tr>
            <td><img class="imj" src ="image/argentine.png" >Argentine</td>
            <td><img class="imj" src ="image/italy.png" >Italy</td>
            <td><img class="imj" src ="image/allemagne.png" >Allemagne</td>
            <td><img class="imj" src ="image/haiti2.png" >Haiti</td>
        </tr>
 
    </table>

    <form action="tirage.php" method="post">
      
    <input type="submit" value="Tirage" name="tirage" class="tirage">
        
        

    </form>
</body>

<footer>
   
<div class="footer">
        <h2>Information</h2>
        <p> 
            Tabare, boulvard 15 octobre <br>
            Port-au-price ,Haïti<br><br>
            .ht<br>
            +(509) 33293791/36111622       
        </p>
    </div>
    <div class="footer1">
        <h3>Nos Réseaux</h3>
        <img src ="image/face.png" >
        <img src ="image/insta.png">
        <img src ="image/twet.png">       
    </div>
   
    <div class="footer4">
        <h4>LES EQUIPES</h4>
        <p> 
            <ul>
                <li>
                    <h3><a href="indexx.html">BRESIL</a></h3> 
                </li>
                <li>
                    <h3><a href="produit.html">ARGENTINE</a></h3> 
                </li>
                <li>
                    <h3><a href="commander.html">FRANCE</a></h3> 
                </li>
                <li>
                    <h3><a href="contact.html">ALLEMAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">PORTUGALE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ITALIE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ESPAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">HAITI</a></h3> 
                </li>
            </ul>
         </p>
    </div> 
    <div class="imaj">
        <img src ="image/ney1.png">  
    </div>

</footer>

<div class="footer3">
        <p>© Copyright championat du monde 2021 - 2022 </p>
    </div>
</html>

