<?php
session_start();

$groupeA = $_SESSION['groupeA'];
$groupeB = $_SESSION['groupeB'];

if (empty($_SESSION['argentine'])) $_SESSION['argentine'] = $argentine = ["argentine", 0, 0, 0, 0, 0, 0, 0, 0];
else $argentine = $_SESSION['argentine'];

if (empty($_SESSION['bresil'])) $_SESSION['bresil'] = $bresil = ["bresil", 0, 0, 0, 0, 0, 0, 0, 0];
else $bresil = $_SESSION['bresil'];

if (empty($_SESSION['france'])) $_SESSION['france'] = $france = ["france", 0, 0, 0, 0, 0, 0, 0, 0];
else $france = $_SESSION['france'];

if (empty($_SESSION['italie'])) $_SESSION['italie'] = $italie = ["italie", 0, 0, 0, 0, 0, 0, 0, 0];
else $italie = $_SESSION['italie'];

if (empty($_SESSION['espagne'])) $_SESSION['espagne'] = $espagne = ["espagne", 0, 0, 0, 0, 0, 0, 0, 0];
else $espagne = $_SESSION['espagne'];

if (empty($_SESSION['allemagne'])) $_SESSION['allemagne'] = $allemagne = ["allemagne", 0, 0, 0, 0, 0, 0, 0, 0];
else $allemagne = $_SESSION['allemagne'];

if (empty($_SESSION['portugal'])) $_SESSION['portugal'] = $portugal = ["portugal", 0, 0, 0, 0, 0, 0, 0, 0];
else $portugal = $_SESSION['portugal'];

if (empty($_SESSION['haiti'])) $_SESSION['haiti'] = $haiti = ["haiti", 0, 0, 0, 0, 0, 0, 0, 0];
else $haiti = $_SESSION['haiti'];


$ga1 = strtolower($groupeA[0]);
$ga2 = strtolower($groupeA[1]);
$ga3 = strtolower($groupeA[2]);
$ga4 = strtolower($groupeA[3]);

$teamGA = [
    0 => $_SESSION[$ga1],
    1 => $_SESSION[$ga2],
    2 => $_SESSION[$ga3],
    3 => $_SESSION[$ga4]
];

for ($i = 0; $i < 4; $i++) {
    for ($j = 0; $j < 4; $j++) {
        if ($teamGA[$i][8] < $teamGA[$j][8]) {
            $tp = $teamGA[$i];
            $teamGA[$i] = $teamGA[$j];
            $teamGA[$j] = $tp;
        }
        if ($teamGA[$i][8] == $teamGA[$j][8]) {
            if ($teamGA[$i][7] < $teamGA[$j][7]) {
                $tp = $teamGA[$i];
                $teamGA[$i] = $teamGA[$j];
                $teamGA[$j] = $tp;
            }
        }
    }
}


// GROUPE B

$gb1 = strtolower($groupeB[0]);
$gb2 = strtolower($groupeB[1]);
$gb3 = strtolower($groupeB[2]);
$gb4 = strtolower($groupeB[3]);

$teamGB = [
    0 => $_SESSION[$gb1],
    1 => $_SESSION[$gb2],
    2 => $_SESSION[$gb3],
    3 => $_SESSION[$gb4]
];

for ($i = 0; $i < 4; $i++) {
    for ($j = 0; $j < 4; $j++) {
        if ($teamGB[$i][8] < $teamGB[$j][8]) {
            $tp = $teamGB[$i];
            $teamGB[$i] = $teamGB[$j];
            $teamGB[$j] = $tp;
        }
        if ($teamGB[$i][8] == $teamGB[$j][8]) {
            if ($teamGB[$i][7] < $teamGB[$j][7]) {
                $tp = $teamGB[$i];
                $teamGB[$i] = $teamGB[$j];
                $teamGB[$j] = $tp;
            }
        }
    }
}

if (!empty($_SESSION['tousLesMatch'])) {
    if (count($_SESSION['tousLesMatch']) == 12) {
        $_SESSION['qualif1'] = $teamGA[3][0];
        $_SESSION['qualif2'] = $teamGB[3][0];
        $_SESSION['qualif3'] = $teamGA[2][0];
        $_SESSION['qualif4'] = $teamGB[2][0];
    }

    


} else {
    $_SESSION['qualif1'] = '';
    $_SESSION['qualif2'] = '';
    $_SESSION['qualif3'] = '';
    $_SESSION['qualif4'] = '';
}

if(empty($_SESSION['1er_petit_final'])){
    $_SESSION['1er_petit_final'] = "*";
}

if(empty($_SESSION['2eme_petit_final'])){
    $_SESSION['2eme_petit_final'] = "*";
}
    



if(empty($_SESSION['1erfinalist'])){
    $_SESSION['1erfinalist'] = "*";
}

if(empty($_SESSION['2eme_finalist'])){
    $_SESSION['2eme_finalist'] = "*";
}

// else
// $_SESSION['1erfinalist'] = $_SESSION['1erfinalist'];
// $_SESSION['2eme_finalist'] = $_SESSION['2eme_finalist'];


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style4.css">
    <title>Classement</title>
</head>

<body>
    <nav>

        <div class="navima">
            <a href="#"> <img src="image/info.png"></a>
        </div>

        <ul>
            <li><a href="index.php">Accueil</a></li>
            <li><a href="tirage.php">Groupes</a></li>
            <li><a href="match.php">Match</a></li>
            <li><a href="classement.php">Classement</a></li>
        </ul>
        <div class="navimaj">
            <a href="#"> <img src="image/face.png"></a>
            <a href="#"><img src="image/insta.png"></a>
            <a href="#"><img src="image/twet.png"></a>
        </div>
        <div class="rechech">

            <input style="" type="shearch" placeholder="recherche">
            <img src="image/rech.png">
        </div>
    </nav>

    <table class="poule_A">
        <thead>
            <tr>
                <th>*</th>
                <th>Equipe</th>
                <th>mj</th>
                <th>mg</th>
                <th>mn</th>
                <th>mp</th>
                <th>bp</th>
                <th>bc</th>
                <th>diff</th>
                <th>pts</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td><?= $teamGA[3][0] ?></td>
                <td><?= $teamGA[3][1] ?></td>
                <td><?= $teamGA[3][2] ?></td>
                <td><?= $teamGA[3][3] ?></td>
                <td><?= $teamGA[3][4] ?></td>
                <td><?= $teamGA[3][5] ?></td>
                <td><?= $teamGA[3][6] ?></td>
                <td><?= $teamGA[3][7] ?></td>
                <td><?= $teamGA[3][8] ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td><?= $teamGA[2][0] ?></td>
                <td><?= $teamGA[2][1] ?></td>
                <td><?= $teamGA[2][2] ?></td>
                <td><?= $teamGA[2][3] ?></td>
                <td><?= $teamGA[2][4] ?></td>
                <td><?= $teamGA[2][5] ?></td>
                <td><?= $teamGA[2][6] ?></td>
                <td><?= $teamGA[2][7] ?></td>
                <td><?= $teamGA[2][8] ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td><?= $teamGA[1][0] ?></td>
                <td><?= $teamGA[1][1] ?></td>
                <td><?= $teamGA[1][2] ?></td>
                <td><?= $teamGA[1][3] ?></td>
                <td><?= $teamGA[1][4] ?></td>
                <td><?= $teamGA[1][5] ?></td>
                <td><?= $teamGA[1][6] ?></td>
                <td><?= $teamGA[1][7] ?></td>
                <td><?= $teamGA[1][8] ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td><?= $teamGA[0][0] ?></td>
                <td><?= $teamGA[0][1] ?></td>
                <td><?= $teamGA[0][2] ?></td>
                <td><?= $teamGA[0][3] ?></td>
                <td><?= $teamGA[0][4] ?></td>
                <td><?= $teamGA[0][5] ?></td>
                <td><?= $teamGA[0][6] ?></td>
                <td><?= $teamGA[0][7] ?></td>
                <td><?= $teamGA[0][8] ?></td>
            </tr>

        </tbody>
    </table>



    <!-- GROUPE B -->
    <table class="poule_B">
        <thead>
            <tr>
                <th>*</th>
                <th>Equipe</th>
                <th>mj</th>
                <th>mg</th>
                <th>mn</th>
                <th>mp</th>
                <th>bp</th>
                <th>bc</th>
                <th>diff</th>
                <th>pts</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td><?= $teamGB[3][0] ?></td>
                <td><?= $teamGB[3][1] ?></td>
                <td><?= $teamGB[3][2] ?></td>
                <td><?= $teamGB[3][3] ?></td>
                <td><?= $teamGB[3][4] ?></td>
                <td><?= $teamGB[3][5] ?></td>
                <td><?= $teamGB[3][6] ?></td>
                <td><?= $teamGB[3][7] ?></td>
                <td><?= $teamGB[3][8] ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td><?= $teamGB[2][0] ?></td>
                <td><?= $teamGB[2][1] ?></td>
                <td><?= $teamGB[2][2] ?></td>
                <td><?= $teamGB[2][3] ?></td>
                <td><?= $teamGB[2][4] ?></td>
                <td><?= $teamGB[2][5] ?></td>
                <td><?= $teamGB[2][6] ?></td>
                <td><?= $teamGB[2][7] ?></td>
                <td><?= $teamGB[2][8] ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td><?= $teamGB[1][0] ?></td>
                <td><?= $teamGB[1][1] ?></td>
                <td><?= $teamGB[1][2] ?></td>
                <td><?= $teamGB[1][3] ?></td>
                <td><?= $teamGB[1][4] ?></td>
                <td><?= $teamGB[1][5] ?></td>
                <td><?= $teamGB[1][6] ?></td>
                <td><?= $teamGB[1][7] ?></td>
                <td><?= $teamGB[1][8] ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td><?= $teamGB[0][0] ?></td>
                <td><?= $teamGB[0][1] ?></td>
                <td><?= $teamGB[0][2] ?></td>
                <td><?= $teamGB[0][3] ?></td>
                <td><?= $teamGB[0][4] ?></td>
                <td><?= $teamGB[0][5] ?></td>
                <td><?= $teamGB[0][6] ?></td>
                <td><?= $teamGB[0][7] ?></td>
                <td><?= $teamGB[0][8] ?></td>
            </tr>

        </tbody>
    </table>


    <table class="demi_final">

        <thead>
            <tr>
                <th>Les Demi Finales</th>
            </tr>
        </thead>

        <tr>
            <form action="traitementClassement.php" method="POST">
                <td>1er Demi Final</td>
                <input type="hidden" name="numMatch" value="13">
                <td>
                    <h4><input readonly type="text" name="equipe1" value=<?= $_SESSION['qualif1'] ?> /></h4>
                </td>

                <td>
                    <?php if (empty($_SESSION['match13'])) : ?>
                        <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match13']))
                        echo $_SESSION['match13'][0];
                    ?>
                </td>

                <td>
                    <h5>VS</h5>
                </td>
                <td>
                    <?php if (empty($_SESSION['match13'])) : ?>
                        <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match13']))
                        echo $_SESSION['match13'][1];
                    ?>
                </td>

                <td>

                    <h4><input readonly type="text" name="equipe2" value=<?= $_SESSION['qualif4'] ?> /></h4>
                </td>
                <td>
                    <input type="submit" value="Valider" name="valider" id="valider">
                </td>
            </form>
        </tr>


        <tr>
            <form action="traitementClassement.php" method="POST">
                <td>2eme Demi Final</td>
                <input type="hidden" name="numMatch" value="14">
                <td>
                    <h4><input readonly type="text" name="equipe1" value=<?= $_SESSION['qualif2'] ?> /></h4>
                </td>

                <td>
                    <?php if (empty($_SESSION['match14'])) : ?>
                        <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match14']))
                        echo $_SESSION['match14'][0];
                    ?>
                </td>

                <td>
                    <h5>VS</h5>
                </td>
                <td>
                    <?php if (empty($_SESSION['match14'])) : ?>
                        <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match14']))
                        echo $_SESSION['match14'][1];
                    ?>
                </td>

                <td>
                    <h4><input readonly type="text" name="equipe2" value=<?= $_SESSION['qualif3'] ?> /></h4>
                </td>
                <td>
                    <input type="submit" value="Valider" name="valider" id="valider">
                    
                </td>
            </form>
        </tr>

    </table>

                        

    <table class="petit_final">

        <thead>
            <tr>
                <th>Petit Final</th>

                
            </tr>
        </thead>

        <tr>
            <form action="traitementClassement.php" method="POST">

                <input type="hidden" name="numMatch" value="15">
                <td>
                    <h4><input readonly type="text" name="equipe1" value=<?= $_SESSION['1er_petit_final'] ?> /></h4>

                </td>

                <td>
                    <?php if (empty($_SESSION['match15'])) : ?>
                        <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match15']))
                        echo $_SESSION['match15'][0];
                    ?>
                </td>

                <td>
                    <h5>VS</h5>
                </td>
                <td>
                    <?php if (empty($_SESSION['match15'])) : ?>
                        <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match15']))
                        echo $_SESSION['match15'][1];
                    ?>
                </td>

                <td>

                    <h4><input readonly type="text" name="equipe2" value=<?= $_SESSION['2eme_petit_final'] ?> /></h4>
                </td>
                <td>
                    <input type="submit" value="Valider" name="valider" id="valider" >

                </td>
            </form>
        </tr>
    </table>

    <div class="eme">
        <h2> 3eme de la competition </h2><br>
        <h4 class=".champion_petite_final">
            <?php 
                if (!empty($_SESSION['3eme_compet'])) echo $_SESSION['3eme_compet']; 
        
            ?>
        </h4>
    </div> 


    <table class="grande_final">

        <thead>
            <tr>
                <th>Grande Finales</th>
            </tr>
        </thead>

        <tr>
            <form action="traitementClassement.php" method="POST">
                <input type="hidden" name="numMatch" value="16">
                <td>
                    <h4><input readonly type="text" name="equipe1" value=<?= $_SESSION['1erfinalist'] ?> /></h4>
                </td>

                <td>
                    <?php if (empty($_SESSION['match16'])) : ?>
                        <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match16']))
                        echo $_SESSION['match16'][0];
                    ?>
                </td>

                <td>
                    <h5>VS</h5>
                </td>
                <td>
                    <?php if (empty($_SESSION['match16'])) : ?>
                        <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    <?php endif ?>

                    <?php
                    if (!empty($_SESSION['match16']))
                        echo $_SESSION['match16'][1];
                    ?>
                </td>

                <td>
                    <h4><input readonly type="text" name="equipe2" value=<?= $_SESSION['2eme_finalist'] ?> /></h4>
                </td>
                <td>
                    <input type="submit" value="Valider" name="valider" id="valider">
                </td>
            </form>
        </tr>

    </table>

    <div class="eme">
        <h2> champion </h2><br>
        <h4 class=".champion_grande_final">
            <?php 
                if (!empty($_SESSION['champion'])) echo $_SESSION['champion']; 
        
            ?>
        </h4>
    </div>

</body>
<footer>

    <div class="footer">
        <h2>Information</h2>
        <p>
            Tabare, boulvard 15 octobre <br>
            Port-au-price ,Haïti<br><br>
            .ht<br>
            +(509) 33293791/36111622
        </p>
    </div>
    <div class="footer1">
        <h3>Nos Réseaux</h3>
        <img src="image/face.png">
        <img src="image/insta.png">
        <img src="image/twet.png">
    </div>

    <div class="footer4">
        <h4>LES EQUIPES</h4>
        <p>
        <ul>
            <li>
                <h3><a href="index.html">BRESIL</a></h3>
            </li>
            <li>
                <h3><a href="produit.html">ARGENTINE</a></h3>
            </li>
            <li>
                <h3><a href="commander.html">FRANCE</a></h3>
            </li>
            <li>
                <h3><a href="contact.html">ALLEMAGNE</a></h3>
            </li>
            <li>
                <h3><a href="video.html">PORTUGALE</a></h3>
            </li>
            <li>
                <h3><a href="video.html">ITALIE</a></h3>
            </li>
            <li>
                <h3><a href="video.html">ESPAGNE</a></h3>
            </li>
            <li>
                <h3><a href="video.html">HAITI</a></h3>
            </li>
        </ul>
        </p>
    </div>
    <div class="imaj">
        <img src="image/ney1.png">
    </div>

</footer>

<div class="footer3">
    <p>© Copyright championat du monde 2021 - 2022 </p>
</div>

</html>