<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <title>Document</title>
</head>

<body>

    <header>

    </header>
    <nav>
           
    <div class="navima">
            <a href="#"> <img src ="image/info.png" ></a>    
        </div>
        <ul>
            <li><a href="index.php">Accueil</a></li>
            <li><a href="tirage.php">Groupes</a></li>
            <li><a href="match.php">Match</a></li>
            <li><a href="classement.php">Classement</a></li>
        </ul>
        <div class="navimaj">
            <a href="#"> <img src ="image/face.png" ></a>
            <a href="#"><img src ="image/insta.png"></a>
            <a href="#"><img src ="image/twet.png"></a>     
        </div>
        <div class="rechech">
           
            <input style="" type="shearch" placeholder="recherche "  >
            <img src ="image/rech.png" >
        </div>
    </nav>
    <table class="premiere-journee">
        <thead>
            <caption>
                <h2>Tableau Confrontation</h2>
            </caption>
            <tr>
                <th>Premiere Journee</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>1er Match</td>
                    <input type="hidden" name="numMatch" value="1">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][0]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match1'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="y">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match1']))
                                echo $_SESSION['match1'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match1'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="y">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match1']))
                                echo $_SESSION['match1'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][1]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>





            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>2eme Match</td>
                    <input type="hidden" name="numMatch" value="2">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][2]; ?> ></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match2'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match2']))
                                echo $_SESSION['match2'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match2'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match2']))
                                echo $_SESSION['match2'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][3]; ?> ></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>3eme Match</td>
                    <input type="hidden" name="numMatch" value="3">
                    <td>
                    <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][0]; ?> ></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match3'])) : ?>
                            <select name="scoreEquipe1" id="">
                                <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match3']))
                                echo $_SESSION['match3'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match3'])) : ?>
                            <select name="scoreEquipe2" id="">
                                <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match3']))
                                echo $_SESSION['match3'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][1]; ?> ></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>


            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>4eme Match</td>
                    <input type="hidden" name="numMatch" value="4">
                    <td>
                    <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][2]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match4'])) : ?>
                            <select name="scoreEquipe1" id="">
                                <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match4']))
                                echo $_SESSION['match4'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match4'])) : ?>
                            <select name="scoreEquipe2" id="">
                                <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match4']))
                                echo $_SESSION['match4'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][3]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

    <!-- 2eme journee -->

    <table class="deuxieme_journee">
        <thead>
            <tr>
                <th>Deuxieme Journee</th>
            </tr>
        </thead>
        <tbody>

        <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>1er Match</td>
                    <input type="hidden" name="numMatch" value="5">
                    <td>
                    <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][0]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match5'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match5']))
                                echo $_SESSION['match5'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match5'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match5']))
                                echo $_SESSION['match5'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][2]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>2eme Match</td>
                    <input type="hidden" name="numMatch" value="6">
                    <td>
                    <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][3]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match6'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match6']))
                                echo $_SESSION['match6'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match6'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match6']))
                                echo $_SESSION['match6'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][1]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

           <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>3eme Match</td>
                    <input type="hidden" name="numMatch" value="7">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][0]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match7'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match7']))
                                echo $_SESSION['match7'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match7'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match7']))
                                echo $_SESSION['match7'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][2]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>4eme Match</td>
                    <input type="hidden" name="numMatch" value="8">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][3]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match8'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match8']))
                                echo $_SESSION['match8'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match8'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match8']))
                                echo $_SESSION['match8'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][1]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>
        </tbody>
    </table>


    <!-- 3eme journee -->

    <table class="troisieme_journee">
        <thead>
            <tr>
                <th>Troisieme Journee</th>
            </tr>
        </thead>
        <tbody>
        <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>1er Match</td>
                    <input type="hidden" name="numMatch" value="9">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][0]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match9'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match9']))
                                echo $_SESSION['match9'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match9'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match9']))
                                echo $_SESSION['match9'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][3]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>2eme Match</td>
                    <input type="hidden" name="numMatch" value="10">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeA'][1]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match10'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match10']))
                                echo $_SESSION['match10'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match10'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match10']))
                                echo $_SESSION['match10'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeA'][2]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>3eme Match</td>
                    <input type="hidden" name="numMatch" value="11">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][0]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match11'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match11']))
                                echo $_SESSION['match11'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match11'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="0">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match11']))
                                echo $_SESSION['match11'][1];
                        ?>
                    </td>

                    <td>
                        <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][3]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>

            <tr>
                <form action="traitementClassement.php" method="POST">
                    <td>2eme Match</td>
                    <input type="hidden" name="numMatch" value="12">
                    <td>
                        <h4><input readonly type="text" name="equipe1" value=<?=$_SESSION['groupeB'][1]?> /></h4>
                    </td>
                    
                    <td>
                        <?php if(empty($_SESSION['match12'])) : ?>
                            <select name="scoreEquipe1" id="">
                            <option value="y">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>
                        
                        <?php 
                            if(!empty($_SESSION['match12']))
                                echo $_SESSION['match12'][0];
                        ?>    
                    </td>

                    <td>
                        <h5>VS</h5>
                    </td>
                    <td>
                        <?php if(empty($_SESSION['match12'])) : ?>
                            <select name="scoreEquipe2" id="">
                            <option value="y">score</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        <?php endif ?>

                        <?php 
                            if(!empty($_SESSION['match12']))
                                echo $_SESSION['match12'][1];
                        ?>
                    </td>

                    <td>
                    <h4><input readonly type="text" name="equipe2" value=<?=$_SESSION['groupeB'][2]?> /></h4>
                    </td>
                    <td>
                        <input type="submit" value="Valider" name="valider" id="valider">
                    </td>
                </form>
            </tr>
        </tbody>
    </table>


    

    
</body>
<footer>
   
<div class="footer">
        <h2>Information</h2>
        <p> 
            Tabare, boulvard 15 octobre <br>
            Port-au-price ,Haïti<br><br>
            .ht<br>
            +(509) 33293791/36111622       
        </p>
    </div>
    <div class="footer1">
        <h3>Nos Réseaux</h3>
        <img src ="image/face.png" >
        <img src ="image/insta.png">
        <img src ="image/twet.png">       
    </div>
   
    <div class="footer4">
        <h4>LES EQUIPES</h4>
        <p> 
            <ul>
                <li>
                    <h3><a href="indexx.html">BRESIL</a></h3> 
                </li>
                <li>
                    <h3><a href="produit.html">ARGENTINE</a></h3> 
                </li>
                <li>
                    <h3><a href="commander.html">FRANCE</a></h3> 
                </li>
                <li>
                    <h3><a href="contact.html">ALLEMAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">PORTUGALE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ITALIE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ESPAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">HAITI</a></h3> 
                </li>
            </ul>
         </p>
    </div> 
    <div class="imaj">
        <img src ="image/ney1.png">  
    </div>

</footer>

<div class="footer3">
        <p>© Copyright championat du monde 2021 - 2022 </p>
    </div>
</html>