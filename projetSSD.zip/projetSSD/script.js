let menu = document.querySelector('nav');
let nav = document.querySelector('nav');

menu.onclick = () =>{

  menu.classList.toggle('fa-ti');
  nav.classList.toggle('active');

}

window.onscroll = () =>{

  menu.classList.remove('fa-times');
  navbar.classList.remove('active');

  if(window.scrollY > 60){
    document.querySelector('#scroll-top').classList.add('active');
  }else{
    document.querySelector('#scroll-top').classList.remove('active');
  }

}

