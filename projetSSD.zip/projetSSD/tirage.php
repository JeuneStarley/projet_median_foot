<?php

session_start();

if(!empty($_SESSION['groupeA']))
  $classA = $_SESSION['groupeA'];
else
  $classA = ["", "", "", ""];


if(!empty($_SESSION['groupeB']))
  $classB = $_SESSION['groupeB'];
else
  $classB =["", "", "", ""];

echo '<br>'; 
echo '<br>'; 
echo '<br>'; 

$chapo1=['Bresil','Argentine'];
$chapo2=['France','Italie'];
$chapo3=['Espagne','Allemagne'];
$chapo4=['Haiti','Portugal'];

if(isset ($_POST['tirage'])){
  $classA [0]=$chapo1[random_int(0,1)];
  $classA [1]=$chapo2[random_int(0,1)];
  $classA [2]=$chapo3[random_int(0,1)];
  $classA [3]=$chapo4[random_int(0,1)];

//1ere equipe poule B
if($classA[0]==$chapo1[0]){
  $classB[0]=$chapo1[1];
}
elseif($classA[0]=$chapo1[1]){
  $classB[0]=$chapo1[0];
}

//2eme equipe poule B
if($classA[1]==$chapo2[0]){
  $classB[1]=$chapo2[1];
}
elseif($classA[1]=$chapo2[1]){
  $classB[1]=$chapo2[0];
}


//3eme equipe poule B
if($classA[2]==$chapo3[0]){
  $classB[2]=$chapo3[1];
}
elseif($classA[2]=$chapo3[1]){
  $classB[2]=$chapo3[0];
}

//4eme equipe poule B
if($classA[3]==$chapo4[0]){
  $classB[3]=$chapo4[1];
}
elseif($classA[3]=$chapo4[1]){
  $classB[3]=$chapo4[0];
}

$_SESSION["groupeA"]= $classA;
$_SESSION["groupeB"]= $classB;

}

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>


<nav>
<div class="navima">
            <a href="#"> <img src ="image/info.png" ></a>    
        </div>
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="tirage.php">Groupes</a></li>
        <li><a href="match.php">Match</a></li>
        <li><a href="classement.php">Classement</a></li>
    </ul>
    <div class="navimaj">
            <a href="#"> <img src ="image/face.png" ></a>
            <a href="#"><img src ="image/insta.png"></a>
            <a href="#"><img src ="image/twet.png"></a>     
        </div>
        <div class="rechech">
           
            <input style="" type="shearch" placeholder="recherche" >
            <img src ="image/rech.png" >
        </div>
</nav>



      <!-- 
      <div class="poul">

          <div class="poul1">

            <p class="classA">
            <p class="titre"> GROUPE A</p>
            <hr>

            <?php

             if(!empty($_SESSION['groupeA'])) { 
             foreach($_SESSION["groupeA"] as $key1){
               echo $key1.'<br>';
              }
            }

            ?>
            </p>

          </div>

          <div class="poul2">
             <p class="classB">
             <p class="titre"> GROUPE B</p>
             <hr>
             <?php

              if(!empty($_SESSION['groupeA'])) {
                foreach($_SESSION["groupeB"] as $key1){
                  echo $key1.'<br>';
                }
              }

      
             ?>
            </p>
          </div>

      </div> -->

      <div class="groupe">

      <table class="groupeA">
        <thead>
            <caption>
                <h3>Groupe A</h3>
            </caption>
    </thead>
            
        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeA'][0];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeA'][1];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeA'][2];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeA'][3];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>
       
    </table>


    <table class="groupeB">
        <thead>
            <caption>
                <h3>Groupe B</h3>
            </caption>
    </thead>
            
        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeB'][0];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeB'][1];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeB'][2];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>

        <tr>
            <td>
                  <form action="" method="POST">
                    
                    <h4>
                        <?php
    
                             echo $_SESSION['groupeB'][3];
    
                        ?>
                    </h4>
    
                  </form>
            </td>
        </tr>
       
    </table>
    <form action="tirage.php" method="post">
        <br><br>
        <input type="submit" value="Tirage" name="tirage" class="tirage">
        <br><br><br>
  </form>

      </div>
</body>
<footer>
   
<div class="footer">
        <h2>Information</h2>
        <p> 
            Tabare, boulvard 15 octobre <br>
            Port-au-price ,Haïti<br><br>
            .ht<br>
            +(509) 33293791/36111622       
        </p>
    </div>
    <div class="footer1">
        <h3>Nos Réseaux</h3>
        <img src ="image/face.png" >
        <img src ="image/insta.png">
        <img src ="image/twet.png">       
    </div>
   
    <div class="footer4">
        <h4>LES EQUIPES</h4>
        <p> 
            <ul>
                <li>
                    <h3><a href="indexx.html">BRESIL</a></h3> 
                </li>
                <li>
                    <h3><a href="produit.html">ARGENTINE</a></h3> 
                </li>
                <li>
                    <h3><a href="commander.html">FRANCE</a></h3> 
                </li>
                <li>
                    <h3><a href="contact.html">ALLEMAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">PORTUGALE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ITALIE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">ESPAGNE</a></h3> 
                </li>
                <li>
                    <h3><a href="video.html">HAITI</a></h3> 
                </li>
            </ul>
         </p>
    </div> 
    <div class="imaj">
        <img src ="image/ney1.png">  
    </div>

</footer>

<div class="footer3">
        <p>© Copyright championat du monde 2021 - 2022 </p>
    </div>
</html>