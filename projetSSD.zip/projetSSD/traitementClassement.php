<?php
session_start();

if (empty($_SESSION['argentine'])) {
    $_SESSION['argentine'] = $argentine = ["argentine", 0, 0, 0, 0, 0, 0, 0, 0];
} else $argentine = $_SESSION['argentine'];

if (empty($_SESSION['bresil'])) {
    $_SESSION['bresil'] = $bresil = ["bresil", 0, 0, 0, 0, 0, 0, 0, 0];
} else $bresil = $_SESSION['bresil'];

if (empty($_SESSION['france'])) {
    $_SESSION['france'] = $france = ["france", 0, 0, 0, 0, 0, 0, 0, 0];
} else $france = $_SESSION['france'];

if (empty($_SESSION['italie'])) {
    $_SESSION['italie'] = $italie = ["italie", 0, 0, 0, 0, 0, 0, 0, 0];
} else $italie = $_SESSION['italie'];

if (empty($_SESSION['espagne'])) $_SESSION['espagne'] = $espagne = ["espagne", 0, 0, 0, 0, 0, 0, 0, 0];
else $espagne = $_SESSION['espagne'];

if (empty($_SESSION['allemagne'])) $_SESSION['allemagne'] = $allemagne = ["allemagne", 0, 0, 0, 0, 0, 0, 0, 0];
else $allemagne = $_SESSION['allemagne'];

if (empty($_SESSION['portugal'])) $_SESSION['portugal'] = $portugal = ["portugal", 0, 0, 0, 0, 0, 0, 0, 0];
else $portugal = $_SESSION['portugal'];

if (empty($_SESSION['haiti'])) $_SESSION['haiti'] = $haiti = ["haiti", 0, 0, 0, 0, 0, 0, 0, 0];
else $haiti = $_SESSION['haiti'];

function gagner($nomEquipe, $tabEquipe, $butPour, $butContre)
{
    $tabEquipe[0] = $nomEquipe;
    $tabEquipe[1] += 1;
    $tabEquipe[2] += 1;
    $tabEquipe[3] += 0;
    $tabEquipe[4] += 0;
    $tabEquipe[5] += $butPour;
    $tabEquipe[6] += $butContre;
    $tabEquipe[7] = $tabEquipe[5] - $tabEquipe[6];
    $tabEquipe[8] += 3;

    return $tabEquipe;
}

function perdre($nomEquipe, $tabEquipe, $butPour, $butContre)
{
    $tabEquipe[0] = $nomEquipe;
    $tabEquipe[1] += 1;
    $tabEquipe[2] += 0;
    $tabEquipe[3] += 0;
    $tabEquipe[4] += 1;
    $tabEquipe[5] += $butPour;
    $tabEquipe[6] += $butContre;
    $tabEquipe[7] = $tabEquipe[5] - $tabEquipe[6];
    $tabEquipe[8] += 0;

    return $tabEquipe;
}

function nul($nomEquipe, $tabEquipe, $butPour, $butContre)
{
    $tabEquipe[0] = $nomEquipe;
    $tabEquipe[1] += 1;
    $tabEquipe[2] += 0;
    $tabEquipe[3] += 1;
    $tabEquipe[4] += 0;
    $tabEquipe[5] += $butPour;
    $tabEquipe[6] += $butContre;
    $tabEquipe[7] = $tabEquipe[5] - $tabEquipe[6];
    $tabEquipe[8] += 1;

    return $tabEquipe;
}


if (isset($_POST['valider'])) {

    switch ($_POST['numMatch']) {
        case '1':
            $scoreEquipe1 = $m1[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m1[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($scoreEquipe1 > $scoreEquipe2) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($scoreEquipe2 > $scoreEquipe1) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[0] = $m1;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[0] = $m1;
            }

            $_SESSION['match1'] = $m1;
            break;
        case '2':
            $scoreEquipe1 = $m2[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m2[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m2[0] > $m2[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m2[1] > $m2[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[1] = $m2;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[1] = $m2;
            }

            $_SESSION['match2'] = $m2;
            break;
        case '3':

            $scoreEquipe1 = $m3[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m3[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m3[0] > $m3[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m3[1] > $m3[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[2] = $m3;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[2] = $m3;
            }
            $_SESSION['match3'] = $m3;
            break;

        case '4':
            $scoreEquipe1 = $m4[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m4[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m4[0] > $m4[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m4[1] > $m4[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[3] = $m4;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[3] = $m4;
            }

            $_SESSION['match4'] = $m4;
            break;
        case '5':
            $scoreEquipe1 = $m5[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m5[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m5[0] > $m5[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m5[1] > $m5[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[4] = $m5;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[4] = $m5;
            }

            $_SESSION['match5'] = $m5;
            break;

        case '6':
            $scoreEquipe1 = $m6[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m6[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m6[0] > $m6[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m6[1] > $m6[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[5] = $m6;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[5] = $m6;
            }

            $_SESSION['match6'] = $m6;
            break;

        case '7':
            $scoreEquipe1 = $m7[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m7[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m7[0] > $m7[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m7[1] > $m7[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[6] = $m7;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[6] = $m7;
            }


            $_SESSION['match7'] = $m7;
            break;

        case '8':
            $scoreEquipe1 = $m8[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m8[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m8[0] > $m8[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m8[1] > $m8[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[7] = $m8;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[7] = $m8;
            }

            $_SESSION['match8'] = $m8;
            break;

        case '9':
            $scoreEquipe1 = $m9[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m9[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m9[0] > $m9[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m9[1] > $m9[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[8] = $m9;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[8] = $m9;
            }
            $_SESSION['match9'] = $m9;
            break;

        case '10':
            $scoreEquipe1 = $m10[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m10[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m10[0] > $m10[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m10[1] > $m10[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }
            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[9] = $m10;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[9] = $m10;
            }
            $_SESSION['match10'] = $m10;
            break;

        case '11':
            $scoreEquipe1 = $m11[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m11[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m11[0] > $m11[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else if ($m11[1] > $m11[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }

            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[10] = $m11;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[10] = $m11;
            }
            $_SESSION['match11'] = $m11;
            break;

        case '12':
            $scoreEquipe1 = $m12[0] = $_POST['scoreEquipe1'];
            $scoreEquipe2 = $m12[1] = $_POST['scoreEquipe2'];

            $equipe1 = strtolower($_POST['equipe1']);
            $equipe2 = strtolower($_POST['equipe2']);

            if ($m12[0] > $m12[1]) {

                ${$equipe1} = gagner($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = perdre($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};

            } else if ($m12[1] > $m12[0]) {

                ${$equipe2} = gagner($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);
                ${$equipe1} = perdre($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};

            } else {
                ${$equipe1} = nul($_POST['equipe1'], ${$equipe1}, $scoreEquipe1, $scoreEquipe2);
                ${$equipe2} = nul($_POST['equipe2'], ${$equipe2}, $scoreEquipe2, $scoreEquipe1);

                $_SESSION[$equipe1] = ${$equipe1};
                $_SESSION[$equipe2] = ${$equipe2};
            }
            if(!empty($_SESSION['tousLesMatch'])){
                $tousLesMatch = $_SESSION['tousLesMatch'];
                $tousLesMatch[11] = $m12;
                $_SESSION['tousLesMatch'] = $tousLesMatch;
            }
            else{
                $_SESSION['tousLesMatch'] = $tousLesMatch[11] = $m12;
            }
            $_SESSION['match12'] = $m12;
            break;

            case '13':
            
                $equipe1=$_POST['equipe1'];
                $equipe2=$_POST['equipe2'];

                $scoreEquipe1 = $m13[0] = $_POST['scoreEquipe1'];
                $scoreEquipe2 = $m13[1] = $_POST['scoreEquipe2'];
               
                if($m13[0]>$m13[1]){

                    $_SESSION['1erfinalist'] =$equipe1;
                    $_SESSION['1er_petit_final']=$equipe2;

                }
                elseif($scoreEquipe2>$scoreEquipe1){

                    $_SESSION['1erfinalist']=$equipe2;
                    $_SESSION['1er_petit_final']=$equipe1;
                }

                $_SESSION['match13'] = $m13;
            break;


            case '14':
            
                $equipe1=$_POST['equipe1'];
                $equipe2=$_POST['equipe2'];

                $scoreEquipe1 = $m14[0] = $_POST['scoreEquipe1'];
                $scoreEquipe2 = $m14[1] = $_POST['scoreEquipe2'];
               
                if($m14[0]>$m14[1]){

                    $_SESSION['2eme_finalist'] =$equipe1;
                    $_SESSION['2eme_petit_final']=$equipe2;

                }
                elseif($scoreEquipe2>$scoreEquipe1){

                    $_SESSION['2eme_finalist']=$equipe2;
                    $_SESSION['2eme_petit_final']=$equipe1;
                }
                
                $_SESSION['match14'] = $m14;
            break;

            case '15':
            
                $equipe1=$_POST['equipe1'];
                $equipe2=$_POST['equipe2'];

                $scoreEquipe1 = $m15[0] = $_POST['scoreEquipe1'];
                $scoreEquipe2 = $m15[1] = $_POST['scoreEquipe2'];
               
                if($scoreEquipe1>$scoreEquipe2){

                    $_SESSION['3eme_compet'] =$equipe1;
                    $_SESSION['4eme_compet']=$equipe2;

                }
                elseif($m15[0]>$m15[1]){

                    $_SESSION['3eme_compet']=$equipe2;
                    $_SESSION['4eme_compet']=$equipe1;
                }
                
                $_SESSION['match15'] = $m15;
            break;


            case '16':
            
                $equipe1=$_POST['equipe1'];
                $equipe2=$_POST['equipe2'];

                $scoreEquipe1 = $m16[0] = $_POST['scoreEquipe1'];
                $scoreEquipe2 = $m16[1] = $_POST['scoreEquipe2'];
               
                if($m16[0]>$m16[1]){

                    $_SESSION['champion'] =$equipe1;
                    $_SESSION['2eme_compet']=$equipe2;

                }
                elseif($scoreEquipe2>$scoreEquipe1){

                    $_SESSION['champion']=$equipe2;
                    $_SESSION['2eme_compet']=$equipe1;
                }
                
                $_SESSION['match16'] = $m16;
            break;


        default:
            break;
    }

    header('Location:match.php');
}
